// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../nonnon/neutral/posix.c"

#include "../../nonnon/neutral/filer.c"
#include "../../nonnon/neutral/string_path.c"




// internal
BOOL
n_mac_tools_dotfiles_remover( const n_posix_char *folder )
{

	BOOL ret = FALSE;


	if ( folder != NULL )
	{

		n_posix_DIR *dp = n_posix_opendir_nodot( folder );
		if ( dp == NULL ) { return TRUE; }


		// [!] : 1 == n_posix_strlen( N_POSIX_SLASH )

		n_posix_loop
		{//break;

			n_posix_dirent *dirent = n_posix_readdir( dp );
			if ( dirent == NULL ) { break; }

			n_posix_char *item = n_string_path_make_new( folder, dirent->d_name );

			if ( n_posix_stat_is_dir( item ) )
			{
				n_mac_tools_dotfiles_remover( item );

				if ( dirent->d_name[ 0 ] == n_posix_literal( '.' ) )
				{
					n_filer_remove( item );
				}
			} else
			if ( dirent->d_name[ 0 ] == n_posix_literal( '.' ) )
			{
				n_filer_remove( item );
			}

			n_string_path_free( item );

		}


		n_posix_closedir( dp );


//n_posix_debug_literal( "%d %d", d->dir, d->file );

	}


	return ret;
}

