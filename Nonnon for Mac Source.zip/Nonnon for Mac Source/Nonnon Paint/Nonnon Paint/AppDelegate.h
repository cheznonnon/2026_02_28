//
//  AppDelegate.h
//  Nonnon Paint
//
//  Created by のんのん on 2022/09/13.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate, NSMenuItemValidation>


@end

