// Project Checker
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../nonnon/neutral/dir.c"
#include "../../nonnon/neutral/txt.c"




#define N_PC_STRING_WORKING n_posix_literal( "Working" )




// internal
void
n_pc_go_refresh( NonnonTxtbox *list, n_posix_char *str )
{

	n_txt txt; n_txt_zero( &txt ); n_txt_new( &txt );
	n_txt_mod( &txt, 0, str );

	n_txt *txt_tmp = list.txtbox->txt_data;
	list.txtbox->txt_data = &txt;

	[list display];

	list.txtbox->txt_data = txt_tmp;

	[[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];

	return;
}

// internal
void
n_pc_go_throbber( NonnonTxtbox *list, int phase )
{

	int           cch = 7;
	n_posix_char *str = n_string_alloccopy( cch + 3, N_PC_STRING_WORKING );

	int i = 0;
	n_posix_loop
	{

		if ( i >= phase ) { break; }

		cch += n_posix_snprintf_literal( &str[ cch ], 3 + 1, "%s", N_STRING_DOT );

		i++;

	}

//NSLog( @"%s", str );

	n_pc_go_refresh( list, str );

	n_string_free( str );


	return;
}

BOOL
n_pc_file_is_same( n_posix_char *f, n_posix_char *t )
{

	NSString *nsstr_f = n_mac_str2nsstring( f );
	NSString *nsstr_t = n_mac_str2nsstring( t );


	NSFileManager *fm = [NSFileManager defaultManager];
	return [fm contentsEqualAtPath:nsstr_f andPath:nsstr_t];
}

// internal
n_type_int
n_pc_go_folder_count( NonnonTxtbox *list, const n_posix_char *folder, BOOL is_first )
{

	const  u32        msec  = 250;

	static n_type_int count = 0;
	static u32        timer = 0;
	static int        phase = 0;

	if ( is_first )
	{
		count = 0;
		timer = n_posix_tickcount() + msec;
		phase = 0;
		n_pc_go_throbber( list, phase );
	}


	n_posix_DIR *dp = n_posix_opendir_nodot( folder );
	if ( dp == NULL ) { return 0; }


	n_posix_char *curdir = n_string_path_folder_current_new();
	n_string_path_folder_change_fast( folder );


	n_posix_loop
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }


		if ( n_posix_stat_is_dir( dirent->d_name ) )
		{
			n_pc_go_folder_count( list, dirent->d_name, FALSE );
		}


		if ( timer < n_posix_tickcount() )
		{

			timer = n_posix_tickcount() + msec;

			phase++;
			if ( phase >= 4 ) { phase = 0; }

			n_pc_go_throbber( list, phase );

		}


		count++;

	}


	n_string_path_folder_change_fast( curdir );
	n_string_path_free( curdir );


	n_posix_closedir( dp );


	return count;
}

void
n_pc_go_folder( NonnonTxtbox *list, n_txt *txt_arg, const n_posix_char *f, const n_posix_char *t, BOOL complete_onoff, BOOL is_first )
{

	if ( n_string_is_same( f, t ) ) { return; }


	n_dir d; n_dir_zero( & d );
	if ( n_dir_load( &d, t ) ) { return; }

	if ( 0 >= n_dir_all( &d ) ) { n_dir_free( &d ); return; }


	n_dir_sort_path( &d );


	static n_posix_char *toplevel;
	static n_txt         txt;
	static n_type_real   step;
	static n_type_real   percent_prv;
	static n_type_real   percent_cur;

	if ( is_first )
	{
		toplevel = n_string_path_carboncopy( f );

		n_txt_zero( &txt ); n_txt_new( &txt );

		n_type_int count = n_pc_go_folder_count( list, t, TRUE );

		step        = (n_type_real) 100 / count;
		percent_prv = -1;
		percent_cur =  0;

	}


	n_posix_structstat f_stat;
	n_posix_structstat t_stat;

	n_type_int i = 0;
	n_posix_loop
	{

		if ( i >= n_dir_all( &d ) ) { break; }


		n_posix_char *f_name = n_string_path_make_new( f, n_dir_name( &d, i ) );
		n_posix_char *t_name = n_string_path_make_new( t, n_dir_name( &d, i ) );
//NSLog( @"%s %s", f_name, t_name );

		BOOL is_plus = FALSE;


		BOOL f_is_exist = ( 0 == n_posix_stat( f_name, &f_stat ) );
		BOOL t_is_exist = ( 0 == n_posix_stat( t_name, &t_stat ) );

		if ( ( t_is_exist )&&( FALSE == f_is_exist ) )
		{

			is_plus = TRUE;

			n_posix_char *str = n_string_path_cat( n_posix_literal( "+ : " ), t_name, NULL );

			n_txt_set( &txt, txt.sy, str );

			n_string_path_free( str );

		} else
		if (
			( t_is_exist )
			&&
			( FALSE == S_ISDIR( f_stat.st_mode ) )
			&&
			( FALSE == S_ISDIR( t_stat.st_mode ) )
		)
		{

			// [!] : modified time is different

			if ( ( complete_onoff )&&( FALSE == n_pc_file_is_same( f_name, t_name ) ) )
			{

				n_posix_char *str = n_string_path_cat( n_posix_literal( "? : " ), t_name, NULL );

				n_txt_set( &txt, txt.sy, str );

				n_string_path_free( str );

			} else
			if ( n_time_compare_mtime( f_name, t_name ) )
			{

				n_posix_char *str = n_string_path_cat( n_posix_literal( "! : " ), t_name, NULL );

				n_txt_set( &txt, txt.sy, str );

				n_string_path_free( str );

			}

		}


		if ( ( is_plus == FALSE )&&( S_ISDIR( f_stat.st_mode ) ) )
		{
			n_pc_go_folder( list, txt_arg, f_name, t_name, complete_onoff, FALSE );
		}


		n_string_path_free( f_name );
		n_string_path_free( t_name );


		percent_cur += step;
		if ( trunc( percent_prv ) != trunc( percent_cur ) )
		{
			n_posix_char str[ 100 ];
			n_posix_snprintf_literal( str, 100, "%s (%d%%)", N_PC_STRING_WORKING, (int) trunc( percent_cur ) );

			n_pc_go_refresh( list, str );
		}
		percent_prv = percent_cur;

		i++;

	}

	n_dir_free( &d );


	if ( n_string_is_same( f, toplevel ) )
	{
		n_string_path_free( toplevel );

		n_txt_copy( &txt, txt_arg );
		n_txt_free( &txt );
	}


	return;
}

// internal
void
n_pc_sort( n_txt *txt )
{

	if ( txt->sy <= 1 ) { return; }


	n_type_int count_question    = 0;
	n_type_int count_exclamation = 0;
	n_type_int count_plus        = 0;

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *f = txt->line[ i ];

			if ( f[ 0 ] == n_posix_literal( '?' ) )
			{
				count_question++;
			} else
			if ( f[ 0 ] == n_posix_literal( '!' ) )
			{
				count_exclamation++;
			} else
			if ( f[ 0 ] == n_posix_literal( '+' ) )
			{
				count_plus++;
			}// else

			i++;
			if ( i >= txt->sy ) { break; }
		}

	}


	n_type_int index_question    = 0;
	n_type_int index_exclamation = count_question;
	n_type_int index_plus        = count_question + count_exclamation;


	n_txt txt_new; n_txt_zero( &txt_new ); n_txt_new( &txt_new );

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = txt->line[ i ];
			if ( s[ 0 ] == n_posix_literal( '?' ) )
			{
				n_txt_set( &txt_new, index_question, s ); index_question++;
			}

			i++;
			if ( i >= txt->sy ) { break; }
		}

	}

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = txt->line[ i ];
			if ( s[ 0 ] == n_posix_literal( '!' ) )
			{
				n_txt_set( &txt_new, index_exclamation, s ); index_exclamation++;
			}

			i++;
			if ( i >= txt->sy ) { break; }
		}

	}

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = txt->line[ i ];
			if ( s[ 0 ] == n_posix_literal( '+' ) )
			{
				n_txt_set( &txt_new, index_plus, s ); index_plus++;
			}

			i++;
			if ( i >= txt->sy ) { break; }
		}

	}

	n_txt_free( txt );
	n_txt_alias( &txt_new, txt );


	return;
}

