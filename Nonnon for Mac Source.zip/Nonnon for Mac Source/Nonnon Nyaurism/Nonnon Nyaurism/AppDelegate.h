//
//  AppDelegate.h
//  Nonnon Nyaurism
//
//  Created by のんのん２ on 2025/12/19.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate, NSTextFieldDelegate, NSMenuDelegate, NSMenuItemValidation>

- (void) NonnonNyaurismSliderUIOnOff:(void*)stub L:(BOOL)onoff_l R:(BOOL)onoff_r;

@end

