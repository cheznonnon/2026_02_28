// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : linker problem occurs




#import <AudioToolbox/AudioToolbox.h>
#import <Accelerate/Accelerate.h>




@interface AudioEqualizer : NSObject
{
	AudioBufferList *_inputBuffer;
	AudioBufferList *_outputBuffer;
	AudioUnit        _eqUnit;
	Float32         *_originalSamples;
	UInt32           _sampleCount;
	Float32          _sampleRate;
}

@property (nonatomic, assign) Float32 *originalSamples;
@property (nonatomic, assign) UInt32   sampleCount;
@property (nonatomic, assign) Float32  sampleRate;




- (instancetype)initWithSamples:(Float32*) samples 
		    sampleCount:(UInt32  ) sampleCount 
		     sampleRate:(Float32 ) sampleRate;

- (Float32*)applyEqualizer;
- (void)updateBand:(int)bandIndex gain:(Float32)gain;


@end




@implementation AudioEqualizer

- (instancetype)initWithSamples:(Float32*) samples 
		    sampleCount:(UInt32  ) sampleCount 
		     sampleRate:(Float32 ) sampleRate;
{
	self = [super init];

	if ( self )
	{
		_originalSamples = samples;
		_sampleCount     = sampleCount;
		_sampleRate      = sampleRate;

		[self setupAudioUnit];
		[self setupBuffers];
	}

	return self;
}


- (void)setupAudioUnit
{
	// AudioComponentの設定
	AudioComponentDescription desc;

	desc.componentType         = kAudioUnitType_Effect;
	desc.componentSubType      = kAudioUnitSubType_NBandEQ;
	desc.componentManufacturer = kAudioUnitManufacturer_Apple;
	desc.componentFlags        = 0;
	desc.componentFlagsMask    = 0;

	// AudioComponentの取得
	AudioComponent component = AudioComponentFindNext( NULL, &desc );
	if ( component == NULL )
	{
#ifdef DEBUG
NSLog( @"Error: AudioComponent not found" );
#endif
		return;
	}


	// AudioUnitのインスタンス作成
	OSStatus status = AudioComponentInstanceNew( component, &_eqUnit );
	if ( status != noErr )
	{
#ifdef DEBUG
NSLog( @"Error creating AudioUnit: %d", (int) status );
#endif
		return;
	}

	// バンド数の設定（10バンド）
	UInt32 bandCount = 10;
	status = AudioUnitSetProperty
	(
		_eqUnit,
		kAUNBandEQProperty_NumberOfBands,
		kAudioUnitScope_Global,
		0,
		&bandCount,
		sizeof( bandCount )
	);
	if ( status != noErr )
	{
#ifdef DEBUG
NSLog( @"Error setting band count: %d", (int) status );
#endif
	}

	// 各バンドの初期設定
	Float32 frequencies[] = {
		32.0f, 64.0f, 125.0f, 250.0f, 500.0f, 
		1000.0f, 2000.0f, 4000.0f, 8000.0f, 16000.0f
	};

	for ( UInt32 i = 0; i < bandCount; i++ )
	{
		// 周波数の設定
		status = AudioUnitSetParameter
		(
			_eqUnit,
			kAUNBandEQParam_Frequency + i,
			kAudioUnitScope_Global,
			0,
			frequencies[ i ],
			0
		);

		// ゲインの初期化（0dB）
		status = AudioUnitSetParameter
		(
			_eqUnit,
			kAUNBandEQParam_Gain + i,
			kAudioUnitScope_Global,
			0,
			0.0f,
			0
		);

		// Q値の設定（デフォルト値）
		status = AudioUnitSetParameter
		(
			_eqUnit,
			kAUNBandEQParam_Bandwidth + i,
			kAudioUnitScope_Global,
			0,
			1.0f,  // [!] : octave unit
			0
		);

		// フィルタタイプ（ピーキング）
		status = AudioUnitSetParameter
		(
			_eqUnit,
			kAUNBandEQParam_FilterType + i,
			kAudioUnitScope_Global,
			0,
			kAUNBandEQFilterType_Parametric,
			0
		);
	}

	// AudioUnitの初期化
	status = AudioUnitInitialize( _eqUnit );
	if ( status != noErr )
	{
#ifdef DEBUG
NSLog( @"Error initializing AudioUnit: %d", (int) status );
#endif
	}

}

- (void)setupBuffers
{
	_inputBuffer = (AudioBufferList*) malloc( sizeof( AudioBufferList ) + sizeof( AudioBuffer ) );
	_inputBuffer->mNumberBuffers                = 1;
	_inputBuffer->mBuffers[ 0 ].mNumberChannels = 2;
	_inputBuffer->mBuffers[ 0 ].mDataByteSize   = _sampleCount * sizeof( Float32 );
	_inputBuffer->mBuffers[ 0 ].mData           = _originalSamples;

	_outputBuffer = (AudioBufferList*) malloc( sizeof( AudioBufferList ) + sizeof( AudioBuffer ) );
	_outputBuffer->mNumberBuffers                = 1;
	_outputBuffer->mBuffers[ 0 ].mNumberChannels = 2;
	_outputBuffer->mBuffers[ 0 ].mDataByteSize   = _sampleCount * sizeof( Float32 );
	_outputBuffer->mBuffers[ 0 ].mData           = malloc( _sampleCount * sizeof( Float32 ) );
}

- (Float32 *)applyEqualizer
{
	if ( _eqUnit == NULL )
	{
#ifdef DEBUG
NSLog(@"AudioUnit not initialized");
#endif
		return _originalSamples;
	}

	// オーディオフォーマットの設定
	AudioStreamBasicDescription asbd; memset( &asbd, 0, sizeof( AudioStreamBasicDescription ) );
 
	asbd.mSampleRate       = _sampleRate;
	asbd.mFormatID         = kAudioFormatLinearPCM;
	asbd.mFormatFlags      = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked;
	asbd.mBytesPerPacket   = sizeof( Float32 );
	asbd.mFramesPerPacket  = 1;
	asbd.mBytesPerFrame    = sizeof( Float32 );
	asbd.mChannelsPerFrame = 1;
	asbd.mBitsPerChannel   = 32;

	// フォーマットをAudioUnitに設定
	OSStatus status = AudioUnitSetProperty
	(
		_eqUnit,
		kAudioUnitProperty_StreamFormat,
		kAudioUnitScope_Input,
		0,
		&asbd,
		sizeof( AudioStreamBasicDescription )
	);

	if ( status != noErr )
	{
#ifdef DEBUG
NSLog( @"Error setting input format: %d", (int) status );
#endif
		return _originalSamples;
	}


	status = AudioUnitSetProperty
	(
		_eqUnit,
		kAudioUnitProperty_StreamFormat,
		kAudioUnitScope_Output,
		0,
		&asbd,
		sizeof( AudioStreamBasicDescription )
	);

	if ( status != noErr )
	{
#ifdef DEBUG
NSLog( @"Error setting output format: %d", (int) status );
#endif
		return _originalSamples;
	}


	// レンダリングコールバックの設定

	AURenderCallbackStruct renderCallback;

	renderCallback.inputProc       = RenderCallback;
	renderCallback.inputProcRefCon = (__bridge void *)self;

	status = AudioUnitSetProperty
	(
		_eqUnit,
		kAudioUnitProperty_SetRenderCallback,
		kAudioUnitScope_Input,
		0,
		&renderCallback,
		sizeof( AURenderCallbackStruct )
	);

	if ( status != noErr )
	{
#ifdef DEBUG
NSLog( @"Error setting render callback: %d", (int) status );
#endif
		return _originalSamples;
	}

	// オーディオ処理の実行
	AudioTimeStamp inTimeStamp; memset( &inTimeStamp, 0, sizeof( AudioTimeStamp ) );

	inTimeStamp.mFlags = kAudioTimeStampSampleTimeValid;

	UInt32 frameCount = _sampleCount;

	status = AudioUnitRender
	(
		_eqUnit,
		NULL,
		&inTimeStamp,
		0,
		frameCount,
		_outputBuffer
	);

	if ( status != noErr )
	{
#ifdef DEBUG
NSLog(@"Error rendering audio: %d", (int)status);
#endif
		return _originalSamples;
	}


	return (Float32*) _outputBuffer->mBuffers[ 0 ].mData;
}

static OSStatus RenderCallback(
	                            void *inRefCon,
	      AudioUnitRenderActionFlags *ioActionFlags,
	const             AudioTimeStamp *inTimeStamp,
	                          UInt32  inBusNumber,
	                          UInt32  inNumberFrames,
	                 AudioBufferList *ioData
)
{
	AudioEqualizer *self = (__bridge AudioEqualizer*) inRefCon;

	memcpy
	(
		ioData->mBuffers[ 0 ].mData,
		self->_originalSamples,
		inNumberFrames * sizeof( Float32 )
	);

	return noErr;
}

- (void)updateBand:(int)bandIndex gain:(Float32)gain
{
	if ( _eqUnit == NULL ) { return; }

	OSStatus status = AudioUnitSetParameter
	(
		_eqUnit,
		kAUNBandEQParam_Gain + bandIndex,
		kAudioUnitScope_Global,
		0,
		gain,
		0
	);

	if ( status != noErr )
	{
#ifdef DEBUG
NSLog( @"Error updating band %d: %d", bandIndex, (int) status );
#endif
	}

}

- (void)dealloc
{

	if ( _eqUnit )
	{
		AudioUnitUninitialize( _eqUnit );
		AudioComponentInstanceDispose( _eqUnit );
	}

	if ( _inputBuffer )
	{
		free( _inputBuffer );
	}

	if ( _outputBuffer )
	{
		if ( _outputBuffer->mBuffers[ 0 ].mData )
		{
			free( _outputBuffer->mBuffers[ 0 ].mData );
		}
		free( _outputBuffer );
	}

}

@end
